from django.db import models


# Create your models here.

class Group(models.Model):
    # verbose_name设置在Django Admin管理后台页面上显示的字段名
    group_name = models.CharField(max_length=32, verbose_name='团体名称')
    group_script = models.CharField(max_length=60, verbose_name='备注')
