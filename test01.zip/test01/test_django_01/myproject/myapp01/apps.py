from django.apps import AppConfig


class Myapp01Config(AppConfig):
    name = 'myapp01'
