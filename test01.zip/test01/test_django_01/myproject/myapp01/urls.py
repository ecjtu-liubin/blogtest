from django.urls import path
from .views import *

urlpatterns = [
    path('index/',index),
    path('test/',test),
    path('login/',login),
    # path('test_filter/',test_filter,name='test_filter'),
]