from django.shortcuts import render, redirect
from django.shortcuts import HttpResponse  # 导入函数，这个函数把传入参数的内容显示在网页上
from django.urls import reverse

# Create your views here.在此处编写视图函数代码，实现业务逻辑
def index(request):
    return HttpResponse('<h1>Hello world<h1>')


def test(request):
    hi = '你好'
    test = '这是一个测试页面，动态页面正常显示，测试成功'
    return render(request, 'test.html', {'hi': hi, 'test': test})


def login(request):
    if request.method == "GET":#判断提交方式，在HTML中method可以是小写，在views.py中必须是大写
        return render(request, 'login.html')
    else:
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username == 'test' and password == '123':
            return redirect('/test/')
        else:
            return render(request, 'login.html', {'error': '用户名或密码错误！'})


def hello(request):
    return render(request,'hello.html')


def ny(request,year,month):
    #参数都是int类型，需要转化成字符类型
    year1 = str(year) + '年'
    month1 = str(month) + '月'
    # 通过render（）函数向ny.html模板变量传递year和month
    return render(request,'ny.html',{'year':year1,'month':month1})


def name(request,username):
    if username == 'redirectny':
        # 反向解析出地址，并通过redirect（）转向这个地址
        # 通过args向URL传递参数值
        return redirect(reverse('ny',args=(2019,6,)))
    else:
        welcome = "欢迎你，"+username
        return render(request,'name.html',{'welcome':welcome})