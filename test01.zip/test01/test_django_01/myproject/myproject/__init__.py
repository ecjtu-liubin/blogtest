import pymysql
pymysql.install_as_MySQLdb()#指明以pymysql模块代替MySQLdb模块