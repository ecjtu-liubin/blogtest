from django.apps import AppConfig


class TestViewConfig(AppConfig):
    name = 'test_view'
