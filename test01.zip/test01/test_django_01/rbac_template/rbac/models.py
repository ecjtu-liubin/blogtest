from django.db import models


# Create your models here.
class Role(models.Model):
    # 角色表，应用项目可以根据需求在表中增加角色纪录
    title = models.CharField(max_length=32,unique=True,verbose_name="角色名")
    permission = models.ManyToManyField("Permission",blank=True,verbose_name="拥有权限")
    def __str__(self):
        return self.title
    class Meta:
        verbose_name = "角色表"
        verbose_name_plural = verbose_name


class UserInfo(models.Model):
    # 用户表，应用项目中的用户放在这个表中
    username = models.CharField(max_length=32)
    password = models.CharField(max_length=64)
    nikename = models.CharField(max_length=32)
    email = models.EmailField()
    roles = models.ManyToManyField("Role")
    def __str__(self):
        return self.nikename
    class Meta:
        verbose_name = "用户表"
        verbose_name_plural = verbose_name


class Permission(models.Model):
    # 权限表，用户根据应用项目划分好权限，然后输入这张表
    title = models.CharField(max_length=32,unique=True,verbose_name="权限名称")
    url = models.CharField(max_length=128,unique=True,verbose_name="URL")
    perm_code = models.CharField(max_length=32,verbose_name="权限代码")
    perm_group = models.ForeignKey(to="PermGroup",blank=True,on_delete=models.CASCADE,verbose_name="所属权限组")
    pip = models.ForeignKey(to="Permission",null=True,blank=True,on_delete=models.CASCADE,verbose_name="二级菜单")
    def __str__(self):
        return self.title
    class Meta:
        verbose_name_plural = "权限表"


class PermGroup(models.Model):
    title = models.CharField(max_length=32,verbose_name="组名称")
    menu = models.ForeignKey(to="Menu",verbose_name="所属菜单",blank=True,on_delete=models.CASCADE)
    def __str__(self):
        return self.title
    class Meta:
        verbose_name_plural = "权限组"


class Menu(models.Model):
    title = models.CharField(max_length=32,unique=True,verbose_name="一级菜单")
    def __str__(self):
        return self.title
    class Meta:
        verbose_name_plural = "一级菜单表"

