from django import forms


# 定义表单要继承Form类
class test_form(forms.Form):
    account = forms.CharField(min_length=10, label="账号", label_suffix='@@', initial='123'
                              , error_messages={"required": "不能为空", "min_length": "编码最少十位"}, disabled=True)
    password = forms.CharField(label="密码", help_text='请输入密码',
                               widget=forms.PasswordInput(attrs={'class': 'password'}, render_value=True), )
    url = forms.URLField(widget=forms.URLInput())
