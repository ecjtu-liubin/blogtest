from django.db import models


# Create your models here.
# 员工数据模型
class employee(models.Model):
    name = models.CharField(max_length=32, verbose_name='姓名')
    email = models.EmailField(verbose_name='邮箱')

    # 员工部门，Foreignkey类型，与department表中的记录形成一对多关系
    # on_delete = models.CASCADE表示如果外键关联的department表中的一条记录被删除
    # 本表中与这条记录相关联的记录将全被删掉
    # 数据模型在生产数据表时，外键在数据表中产生的字段名为dep_id
    dep = models.ForeignKey(to="department", on_delete=models.CASCADE)
    group = models.ManyToManyField(to="group")
    salary = models.DecimalField(max_digits=8, decimal_places=2)
    # 一对一键在数据表中产生的字段名为info_id
    info = models.OneToOneField(to='employeeinfo', on_delete=models.CASCADE, null=True)


# 部门数据模型
class department(models.Model):
    dep_name = models.CharField(max_length=32, verbose_name='部门名称')
    dep_script = models.CharField(max_length=60, verbose_name='备注')


# 团体数据模型
class group(models.Model):
    group_name = models.CharField(max_length=32, verbose_name='团体名称')
    group_script = models.CharField(max_length=60, verbose_name='备注')


# 员工补充信息表
class employeeinfo(models.Model):
    phone = models.CharField(max_length=11)
    address = models.CharField(max_length=50)

