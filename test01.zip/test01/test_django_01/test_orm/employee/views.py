from django.shortcuts import render, redirect, HttpResponse
from .models import employee, department, group, employeeinfo
from . import forms

# Create your views here.

def list_employee_old(request):
    # 取出employee数据表中全部记录
    emp = employee.objects.all()
    return render(request,'test_orm_old/list_employee_old.html',{'emp_list':emp})


def add_employee_old(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        dep = request.POST.get('dep')
        info = request.POST.get('info')
        salary = request.POST.get('salary')
        # 取得多个值
        groups = request.POST.getlist('group')
        print(groups)
        new_emp = employee.objects.create(name=name,email=email,salary=salary,dep_id=dep,info_id =info)
        # 给多对对键赋值
        new_emp.group.set(groups)
        new_emp.save()
        return redirect('/test_orm_old/list_employee_old/')
    dep_list = department.objects.all()
    group_list = group.objects.all()
    info_list = employeeinfo.objects.all()
    return render(request,'test_orm_old/add_employee_old.html',{'dep_list':dep_list,'group_list':group_list,
                                                                'info_list':info_list})


def edit_employee_old(request,emp_id):
    if request.method == 'POST':
        id = request.POST.get('id')
        name = request.POST.get('name')
        email = request.POST.get('email')
        dep = request.POST.get('dep')
        info = request.POST.get('info')
        groups = request.POST.getlist('group')
        emp = employee.objects.get(id=id)
        emp.name = name
        emp.email = email
        emp.dep_id = dep
        emp.info_id = info
        emp.group.set(groups)
        emp.save()
        return redirect('/test_orm_old/list_employee_old/')
    emp = employee.objects.get(id=emp_id)
    dep_list = department.objects.all()
    group_list = group.objects.all()
    info_list = employeeinfo.objects.all()
    return render(request,'test_orm_old/edit_employee_old.html',{'emp':emp,'dep_list':dep_list,'group_list':group_list,
                                                                'info_list':info_list})


def delete_employee_old(request,emp_id):
    emp_object = employee.objects.get(id=emp_id)
    emp_object.delete()
    return redirect('/test_orm_old/list_employee_old/')



def add_dep_old(request):
    # 判断请求方式，如果是POST，说明前端页面要提交数据
    if request.method == 'POST':
        dep_name = request.POST.get('dep_name')
        dep_script = request.POST.get('dep_script')
        if dep_name.strip() == '':
            return render(request, 'term_orm_old/add_dep_old.html', {'error_info': '部门名不能为空'})
        try:
            # 用creat（）函数新建一条记录，这条记录会自动保存，不用调用save（）函数
            p = department.objects.create(dep_name=dep_name, dep_script=dep_script)
            return redirect('/test_orm_old/list_dep_old/')
        except Exception as e:
            return render(request, 'test_orm_old/add_dep_old.html', {'error_info': '输入部门名称重复或信息有误！'})
        finally:
            pass
    # 如果判断出不是POST提交，表示是第一次访问页面， 显示增加部门页面
    return render(request, 'test_orm_old/add_dep_old.html')


def list_dep_old(request):
    # 取得数据库表的全部数据
    dep_list = department.objects.all()
    return render(request, 'test_orm_old/list_dep_old.html', {'dep_list': dep_list})


def del_dep_old(request, dep_id):
    department.objects.filter(id=dep_id).delete()
    # dep_object = department.objects.get(id=dep_id)
    # dep_object.delete()
    return redirect('/test_orm_old/list_dep_old/')


def edit_dep_old(request, dep_id):
    if request.method == 'POST':
        id = request.POST.get('id')
        # 获取前端页面提交的数据
        dep_name = request.POST.get('dep_name')
        dep_script = request.POST.get('dep_script')
        dep_object = department.objects.get(id=id)
        # 给字段赋值
        dep_object.dep_name = dep_name
        dep_object.dep_script = dep_script
        # 保存到数据库
        dep_object.save()
        return redirect('/test_orm_old/list_dep_old/')
    else:
        dep_object = department.objects.get(id=dep_id)
        return render(request, 'test_orm_old/edit_dep_old.html', {'department': dep_object})


def add_group_old(request):
    if request.method == 'POST':
        group_name = request.POST.get('group_name')
        group_script = request.POST.get('group_script')
        if group_name.strip() == '':
            return render(request, 'test_orm_old/add_group_old.html', {'error_info': '团体名称不能为空！'})
        try:
            group.objects.create(group_name=group_name, group_script=group_script)
            return redirect('/test_orm_old/list_group_old/')
        except Exception as e:
            return render(request, 'test_orm_old/add_group_old.html', {'error': '输入团体名称重复或信息有误!'})
        finally:
            pass
    return render(request, 'test_orm_old/add_group_old.html')


def list_group_old(request):
    group_list = group.objects.all()
    return render(request, 'test_orm_old/list_group_old.html', {'group_list': group_list})


def del_group_old(request,group_id):
    group.objects.filter(id=group_id).delete()
    return redirect('/test_orm_old/list_group_old/')


def edit_group_old(request,group_id):
    if request.method == 'POST':
        id = request.POST.get('id')
        group_name = request.POST.get('group_name')
        group_script = request.POST.get('group_script')
        group_objects = group.objects.get(id=id)
        group_objects.group_name = group_name
        group_objects.group_script = group_script
        group_objects.save()
        return redirect('/test_orm_old/list_group_old/')
    else:
        group_objects =group.objects.get(id=group_id)
        return render(request,'test_orm_old/edit_group_old.html',{'group':group_objects})


def add_employeeinfo_old(request):
    if request.method == 'POST':
        phone =request.POST.get('phone')
        address = request.POST.get('address')
        if phone.strip() == '':
            return render(request,'test_orm_old/add_employeeinfo_old.html',{'error_info':'电话号码不能为空！'})
        try:
            employeeinfo.objects.create(phone=phone,address=address)
            return redirect('/test_orm_old/list_employeeinfo_old/')
        except Exception as e:
            return render(request,'test_orm_old/add_employeeinfo_old.html',{'error_info':'信息有误！'})
        finally:
            pass
    return render(request,'test_orm_old/add_employeeinfo_old.html')


def list_employeeinfo_old(request):
    info_list = employeeinfo.objects.all()
    return render(request,'test_orm_old/list_employeeinfo_old.html',{'info_list': info_list})


def del_employeeinfo_old(request,info_id):
    info_object = employeeinfo.objects.get(id=info_id)
    info_object.delete()
    return redirect('/test_orm_old/list_employeeinfo_old/')


def edit_employeeinfo_old(request,info_id):
    if request.method == 'POST':
        id = request.POST.get('id')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        info_object = employeeinfo.objects.get(id=id)
        info_object.phone = phone
        info_object.address = address
        info_object.save()
        return redirect('/test_orm_old/list_employeeinfo_old/')
    else:
        info_object = employeeinfo.objects.get(id=info_id)
        return render(request,'test_orm_old/edit_employeeinfo_old.html',{'info':info_object})


def test_foreign(request):
    # 取出employee的一条记录
    emp = employee.objects.get(id=30)
    # dep = emp.dep
    # print(dep)
    dep_name = emp.dep.dep_name
    dep_obj =department.objects.get(id=2)
    # dep_obj.employee_set.set(88)# 错误语句
    # emp = dep_obj.employee_set
    # print(emp)
    emp_list = dep_obj.employee_set.all()
    emp_names = [emp.name for emp in emp_list]

    dep_emp_2 = department.objects.values("employee__name","employee__email")
    print(dep_emp_2)
    return HttpResponse("1.正向关联：员工名称：{0}，所在部门：{1} <br> 2.反向查找：部门名称：{2}，部门员工：{3}"
                        .format(emp.name,dep_name,dep_obj.dep_name,emp_names))


#以下为美化的相关视图函数
def index(request):
    return render(request,'test_orm/index.html')


def testform(request):
    if request.method == 'POST':
        # 通过request.POST为test_form对象赋值
        test_form = forms.test_form(request.POST)
        # 表单校验功能
        if test_form.is_valid():
            # 校验通过的数据存放在cleaned_data中，cleaned_data是字典类型，因此要用get()函数取值
            account = test_form.cleaned_data.get("account")
            pw = test_form.cleaned_data.get("password")
            if account=='test' and pw=='123':
                return HttpResponse("登陆成功")
            else:
                return HttpResponse("用户名或密码错误！")
        else:
            return HttpResponse("输入数据不合法")
    # 初始化生成一个test_form对象
    test_form = forms.test_form()
    # 通过render()把test_form表单对象传递给test_form
    return render(request,'test_form.html',{'testform':test_form})