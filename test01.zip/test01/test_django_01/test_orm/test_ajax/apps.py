from django.apps import AppConfig


class TestAjaxConfig(AppConfig):
    name = 'test_ajax'
