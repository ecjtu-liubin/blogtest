from django.db import models


# Create your models here.
class person(models.Model):
    name = models.CharField(max_length=32,verbose_name='姓名')
    email = models.EmailField(verbose_name='邮箱')
    salary = models.DecimalField(max_digits=8,decimal_places=2)
    def __str__(self):
        return self.name
