from django.contrib import admin
from . import models


# Register your models here.
class authorityadmin(admin.ModelAdmin):
    #管理后台列表页面上显示的字段
    list_display = ('codename','url','name')


admin.site.register(models.authority,authorityadmin)