from django.apps import AppConfig


class TestAuthConfig(AppConfig):
    name = 'test_auth'
