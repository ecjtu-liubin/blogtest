from django.db import models
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.models import Permission


# Create your models here.
class authority(models.Model):
    codename = models.CharField("权限代码",max_length=32)
    url = models.CharField("URL配置项名称",max_length=128)
    name = models.CharField("权限描述",max_length=120)
    def save(self,*args,**kwargs):
        # 取得content_type对象，该对象与test_auth中的authority数据模型有关联
        content_type_obj = ContentType.objects.get(app_label = 'test_auth',model='authority')
        # 增加一个权限，权限代码与字段codename的值相同，权限名与字段name的值相同
        permission = Permission.objects.create(codename=self.codename,name=self.name,content_type=content_type_obj)
        # 调用父类的save方法将数据记录保存到数据库中
        super(authority,self).save(*args,**kwargs)
    def delete(self,*args,**kwargs):
        # 取得content对象
        content_type_obj = ContentType.objects.get(app_label='test_auth',model='authority')
        # 取出权限对象
        permission = Permission.objects.get(codename=self.codename,content_type=content_type_obj)
        # 删除权限
        permission.delete()
        # 调用父类的delete()方法，删除这条记录
        super(authority, self).delete(*args,**kwargs)
    def __str__(self):
        return self.name
    class Meta:
        verbose_name = '权限表'
        verbose_name_plural = verbose_name