from django.apps import AppConfig


class TestFormConfig(AppConfig):
    name = 'test_form'
