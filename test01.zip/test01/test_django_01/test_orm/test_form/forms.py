from django import forms


class login_form(forms.Form):
    account = forms.CharField(
        min_length=2,
        label="账号",
        widget=forms.widgets.TextInput(attrs={"class":"form-control","placeholder":"请输入账号","autofocus":True})
    )
    pwd = forms.CharField(
        min_length=6,
        label='密码',
        widget=forms.widgets.PasswordInput(attrs={'class':'form-control',"placeholder":"请输入密码"},render_value=True)
    )


class loguser_form(forms.Form):
    id = forms.IntegerField(label='',
                            widget=forms.widgets.NumberInput(attrs={"hidden":'true'}),required=False)
    account = forms.CharField(label='账号',
                              min_length=2,
                              widget=forms.widgets.TextInput(
                                  attrs={'class':'form-control',"placeholder":'请输入账号','autofocus':True}))
    password = forms.CharField(label='密码',
                               min_length=6,
                               widget=forms.widgets.TextInput(attrs={'class':'form-control','placeholder':'请输入密码'}))
    email = forms.EmailField(label='邮箱',
                             widget=forms.widgets.EmailInput(attrs={'class':'form-control','placeholder':'请输入邮箱'}))
    gender = forms.ChoiceField(label='性别',choices=((1,'男'),(2,'女'),),initial='1',
                               widget=forms.widgets.RadioSelect())
    hobby = forms.ChoiceField(choices=((1,"游泳"),(2,"跑酷"),(3,"自行车"),),
                              label="爱好",initial=3,
                              widget = forms.widgets.Select())
    hair = forms.ChoiceField(label="发量",choices=((1,'很多'),(2,'一般'),(3,'很少'),),
                             widget=forms.widgets.RadioSelect())
    # 图片字段涉及图片上传
    img = forms.ImageField(label='头像',required=False)

