from django.db import models

# Create your models here.
# 导入自定义的模块，这个模块将上传文件按一定格式命名并存储
from utils.rename_upload import RenameUpload
class loguser(models.Model):
    account = models.CharField(max_length=32,verbose_name="登陆账号")
    password = models.CharField(max_length=20,verbose_name='密码')
    email = models.EmailField(verbose_name="邮箱")
    gender = models.CharField(max_length=1,choices=(('1', '男'), ('2', '女'),))
    hobby = models.CharField(max_length=20)
    hair = models.CharField(max_length=1)
    img = models.FileField(upload_to='image',storage=RenameUpload(),blank=True,null=True)