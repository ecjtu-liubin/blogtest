from django.shortcuts import render,redirect,HttpResponse
from . import forms
from . import models
# Create your views here.


def login(request):
    if request.method == 'POST':
        form_obj = forms.login_form(request.POST)
        if form_obj.is_valid():
            account = form_obj.cleaned_data['account']
            pwd = form_obj.cleaned_data['pwd']
            user_obj = models.loguser.objects.filter(account=account,password=pwd).first()
            if user_obj:
                return redirect('/list_loguser/')
            else:
                error = "用户不存在或密码错误！"
                return render(request,'login.html',{'form_obj':form_obj,'errmsg':error})
        else:
            return render(request,'login.html',{'form_obj':form_obj})

    form_obj = forms.login_form()
    return render(request,'login.html',{'form_obj':form_obj})


def list_loguser(request):
    users = models.loguser.objects.all()
    return render(request,'list_loguser.html',{"user_list":users})


def add_loguser(request):
    if request.method == 'POST':
        form_obj = forms.loguser_form(request.POST or None,request.FILES or None)
        if form_obj.is_valid():
            loguser_obj = models.loguser.objects.create(
                account = form_obj.cleaned_data['account'],
                password = form_obj.cleaned_data['password'],
                email = form_obj.cleaned_data['email'],
                gender = form_obj.cleaned_data['gender'],
                hobby = form_obj.cleaned_data['hobby'],
                hair = form_obj.cleaned_data['hair'],
                img = form_obj.cleaned_data['img'],
            )
            return redirect('/list_loguser/')
        else:
            return render(request,'add_loguser.html',{'formobj':form_obj})

    form_obj = forms.loguser_form()
    return render(request,'add_loguser.html',{'formobj':form_obj})


def edit_loguser(request,loguser_id):
    if request.method == 'POST':
        form_obj = forms.loguser_form(request.POST or None,request.FILES or None)
        if form_obj.is_valid():
            id = form_obj.cleaned_data['id']
            loguser_obj = models.loguser.objects.get(id=id)
            loguser_obj.account = form_obj.cleaned_data['account']
            loguser_obj.password = form_obj.cleaned_data['password']
            loguser_obj.email = form_obj.cleaned_data['email']
            loguser_obj.gender = form_obj.cleaned_data['gender']
            loguser_obj.hobby = form_obj.cleaned_data['hobby']
            loguser_obj.hair = form_obj.cleaned_data['hair']
            loguser_obj.img = form_obj.cleaned_data['img']
            # 如果图片文件为空，是因为没有上传新的文件
            # 需要从先预先保存了图片地址的字段img1中取值
            if not loguser_obj.img:
                loguser_obj.img = request.POST.get('img1')
            loguser_obj.save()
            imgname = loguser_obj.img
            # return render(request,'edit_loguser.html',{'formobj':form_obj,'img':imgname})
            return redirect('/list_loguser/')
        else:
            return render(request,'add_loguser.html',{'formobj':form_obj})
    else:
        old_data = models.loguser.objects.filter(id=loguser_id).values()
        imgname = old_data[0]['img']
        form_obj = forms.loguser_form(old_data[0])
        return render(request,'edit_loguser.html',{"formobj":form_obj,'img':imgname})


def del_loguser(request,loguser_id):
    models.loguser.objects.get(id=loguser_id).delete()
    return redirect('/list_loguser/')