from django.apps import AppConfig


class TestMiddlewareConfig(AppConfig):
    name = 'test_middleware'
