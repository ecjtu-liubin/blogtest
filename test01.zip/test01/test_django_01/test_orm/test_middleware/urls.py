from django.urls import path
from . import views

urlpatterns = [
    # 一个普通视图函数的配置项
    path('test/',views.test),
    # 能反复包含render()方法的对象的视图函数的配置项
    path('test2/',views.test2),
]