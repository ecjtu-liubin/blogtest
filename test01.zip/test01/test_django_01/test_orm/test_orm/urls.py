"""test_orm URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from . import settings
from test_view import views
from test_form import views as V

urlpatterns = [
    path('admin/', admin.site.urls),
    # 用include()函数把二级配置包含进来
    path('test_orm_old/',include('employee.urls')),
    path('test_view/',include('test_view.urls')),
    path('test_orm/',include('employee.urls')),

    path('template/',views.template_test),
    path('test_filter/',views.test_filter),
    path('test_tag/',views.test_tag),
    path('test_inclusion_tag/',views.test_inclusion_tag),

    path('inhert/',views.inhert),

    path('login/',V.login),
    path('list_loguser/',V.list_loguser),
    path('add_loguser/',V.add_loguser),
    path('edit_loguser/<int:loguser_id>/',V.edit_loguser),
    path('del_loguser/<int:loguser_id>/',V.del_loguser),

    # 分页组件设计
    path('test_page/',include('test_page.urls')),

    # AJAX使用
    path('test_ajax/',include('test_ajax.urls')),

    # 中间件
    path('test_middleware/',include('test_middleware.urls')),

    # 权限管理
    path('test_auth',include('test_auth.urls')),
 ]+static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
