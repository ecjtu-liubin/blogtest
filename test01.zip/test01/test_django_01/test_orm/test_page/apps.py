from django.apps import AppConfig


class TestPageConfig(AppConfig):
    name = 'test_page'
