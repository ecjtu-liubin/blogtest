from django.urls import path
from . import views
urlpatterns = [
    # 普通分页页面
    path('person_page/',views.person_page),
    path('person_pagenew/',views.person_pagenew),
]