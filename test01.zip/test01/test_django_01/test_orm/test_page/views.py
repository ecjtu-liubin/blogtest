from django.shortcuts import render
from . import models
from utils.paginater import Paginater

# Create your views here.
def person_page(request):
    # 从URL中取出page，这个参数是'?page=1'形式
    # 在视图函数生成的HTML代码片段中设置
    cur_page_num = request.GET.get('page')
    # 取得person中的记录总数
    total_count = models.person.objects.all().count()
    one_page_lines = 10  # 设定每页显示记录数
    page_maxtag = 9  # 页面上一共展示多少页码标签
    total_page,remainder = divmod(total_count,one_page_lines)
    if remainder:
        total_page +=1
    try:
        # 参数page传递进来的是字符类型的数值，因此需要转化成整数类型
        cur_page_num = int(cur_page_num)
        # 如果输入的页码超过了最大页码，设置当前页码是最后一页的页码
        if cur_page_num >total_page:
            cur_page_num = total_page
    except Exception as e:
        # 当输入的页码不是正整数或者不是数字时设置其为第一页的页码
        cur_page_num = 1

    # 定义两个变量，指定表中当前页的记录开始数和记录结束数
    rows_start = (cur_page_num-1)*one_page_lines
    rows_end = cur_page_num *one_page_lines

    # 如果页数小于每页设置的页码标签数，设置每页页码标签数为总页数
    if total_page < page_maxtag:
        page_maxtag = total_page
    half_page_maxtag = page_maxtag // 2
    # 页面上页码标签的开始数
    page_start = cur_page_num - half_page_maxtag
    page_end = cur_page_num + half_page_maxtag
    # 如果计算出的页码标签开始数小于1，页面中页码标签设置为从1开始
    if page_start <=1:
        page_start = 1
        page_end = page_maxtag
    if page_end >= total_page:
        page_end = total_page
        page_start = total_page - page_maxtag+1
        if page_start<=1:
            page_start=1

    per_list = models.person.objects.all()[rows_start:rows_end]  # 取出请求页数据
    html_page = []  # 保存拼接分页的HTML代码
    html_page.append("<li><a href='/test_page/person_page/?page=1'>首页</a></li>")
    # 上一页页码标签的HTML代码，如果当前页是第一页，设置上一页页码标签为非可用状态
    if cur_page_num <=1:
        html_page.append('<li class="disabled"><a href="#"><span aria-hidden="true">&laquo;</span></a></li>')
    else:
        html_page.append('<li><a href="/test_page/person_page/?page={}"><span '
                         'aria-hidden="true">&laquo;</span></a></li> '
                         .format(cur_page_num-1))
    for i in range(page_start,page_end+1):
        if i == cur_page_num:
            html_temp = '<li class="active"><a href="/test_page/person_page/?page={0}">{0}</a></li>'.format(i)
        else:
            html_temp = '<li><a href="/test_page/person_page/?page={0}">{0}</a></li>'.format(i)
        html_page.append(html_temp)
    if cur_page_num>=total_page:
        html_page.append('<li class="disabled"><a href="#"><span aria-hidden="true">&raquo;</span></a></li>')
    else:
        html_page.append('<li><a href="/test_page/person_page/?page={}"><span '
                         'aria-hidden="true">&raquo;</span></a></li> '
                         .format(cur_page_num+1))
    html_page.append("<li><a href='/test_page/person_page/?page={}'>尾页</a></li>".format(total_page))

    page_nav = "".join(html_page)
    return render(request,'test_page/list_person.html',{'person_list':per_list,'page_nav':page_nav})


def person_pagenew(request):
    cur_page_num = request.GET.get('page')
    if not cur_page_num:
        cur_page_num = 1
    total_count = models.person.objects.all().count()
    one_page_line = 6
    page_maxtag = 9
    page_obj = Paginater(url_address='/test_page/person_pagenew/',cur_page_num=cur_page_num,
                         total_rows = total_count,one_page_lines = one_page_line,page_maxtag=page_maxtag)
    per_list = models.person.objects.all()[page_obj.data_start:page_obj.data_end]
    return render(request,'test_page/list_person.html',{'person_list':per_list,'page_nav':page_obj.html_page()})