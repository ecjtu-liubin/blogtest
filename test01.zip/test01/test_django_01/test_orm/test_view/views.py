from django.shortcuts import render, redirect, HttpResponse
from django.views.generic import TemplateView,ListView,DetailView
import datetime
from . import models

# Create your views here.
def hello_view(request):
    vnow = datetime.datetime.now().date().today()

    rep = "<div align='center'><h1>你好，欢迎浏览本页面</h1><hr>当前日期是{}</div>".format(vnow)
    return HttpResponse(rep)


def depdetail(request,dep_id):
    # 根据传入的参数值取出一条记录
    obj = models.department.objects.get(id=dep_id)
    # 返回HTTPResponse对象
    return HttpResponse('部门：'+obj.dep_name+'备注：'+obj.dep_script)


def test_redirect(request):
    obj = models.department.objects.get(id=1)
    # 用redirect()重定向，参数是数据模型对象，所以重定向到数据模型get_absolute_url生成的url
    # 这个url对应的视图函数views.depdetail(),实际上调用这个函数
    return redirect(obj)#redirect参数是数据模型对象时
    # return redirect('depdetail',dep_id=2)#redirect参数是视图函数名称时
    # return redirect('http://127.0.0.1:8000/dep/2')#参数是完整的url时
    # return redirect('/dep/2/')# 参数是不带协议的url时，到urls.py中匹配


class test_templateview(TemplateView):
    # 设置模板文件
    template_name = 'test_view/test_temp.html'
    # 重写父类get_context_data()方法
    def get_context_data(self, **kwargs):
        context = super(test_templateview,self).get_context_data(**kwargs)
        # 增加一个模板变量test
        context['test'] = '这是一个要传递的变量'
        return context

#
# class test_listview(ListView):
#     # 设置数据模型，确定数据记录来源
#     models=models.department
#     # 设置模板文件
#     template_name = 'test_view/test_listview.html'
#     # 设置模板变量，若不设置默认为object_list
#     context_object_name = "dep_list"

class listviewdemo(ListView):
    template_name = "test_view/listviewdemo.html"
    context_object_name = "person_list"
    # 重写get_queryset_name
    def get_queryset(self):
        personlist = models.person.objects.filter(gender='2')
        return personlist
    # 重写父类的get_context_data(),增加模板变量loguser
    def get_context_data(self, **kwargs):
        kwargs['loguser'] = models.loguser.objects.all().first()
        return super(listviewdemo,self).get_context_data(**kwargs)


class detailviewdemo(DetailView):
    model = models.person
    template_name = 'test_view/testdetail.html'
    context_object_name = 'person'
    # urls.py文件的urlpattern列表里的URL表达式中的实名参数
    pk_url_kwarg = 'personid'
    def get_object(self, queryset=None):
        obj = super(detailviewdemo,self).get_object()
        if obj.gender == '1':
            obj.gender = '男'
        else:
            obj.gender = '女'
        return obj
    def get_context_data(self, **kwargs):
        # 增加一个变量
        kwargs['test'] = '这是一个DetailView类通用视图生成的页面'
        return super(detailviewdemo, self).get_context_data(**kwargs)



# 以下是简单人员管理系统的视图函数

def login(request):
    if request.method == 'POST':
        account = request.POST.get('account')
        password = request.POST.get('password')
        remember = request.POST.get('remember')
        # 数据库查询用户
        loguser = models.loguser.objects.filter(account=account,password=password).first()
        if loguser:
            rep = redirect('/test_view/index/')
            if remember == 'on':
                rep.set_cookie('account',account,max_age=60*60*8)
            return rep
        else:
            errmsg = '用户名或密码错误'
            return render(request,'test_view/login.html',{'errmsg':errmsg})
    account = request.COOKIES.get('account','')
    return render(request,'test_view/login.html',{'account_two':account})


def index(request):
    person_list = models.person.objects.all()
    return render(request,'test_view/index.html',{'person_list':person_list})


def add_person(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        email = request.POST.get("email")
        gender = request.POST.get("gender")
        head_img = request.FILES.get('head_img')
        attachment = request.FILES.get('attachment')
        # 生成一条记录
        new_person = models.person.objects.create(name=name,email=email,gender=gender,head_img=head_img,
                                                 attachment=attachment)
        return redirect('/test_view/index/')
    return render(request,'test_view/add_person.html')


def edit_person(request,personid):
    if request.method == 'POST':
        id = request.POST.get('id')
        name = request.POST.get('name')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        head_img = request.FILES.get('head_img')
        attachment = request.FILES.get('attachment')

        person = models.person.objects.get(id=id)
        person.name = name
        person.email = email
        person.gender = gender
        if head_img:
            # 头像文件有值是才修改数据字段的值
            person.head_img = head_img
        if attachment:
            person.attachment = attachment
        person.save()
        return redirect("/test_view/index/")
    person_obj = models.person.objects.get(id=personid)
    return render(request,'test_view/edit_person.html',{'person':person_obj})


def del_person(request,personid):
    person_obj = models.person.objects.get(id=personid)
    person_obj.delete()
    return redirect("/test_view/index/")

# 以上是简单人员管理系统的视图函数
def template_test(request):
    v_list = ['程序员','产品经理','产品销售','架构师']
    v_dic = {'name':'张三','age':16,'love':'编程'}
    class coder(object):
        def __init__(self,name,language,hair):
            self.name = name
            self.language = language
            self.hair = hair

        def hope(self):
            return '{}的希望是程序少出bug，工作少加班！'.format(self.name)

    zhang = coder('张三','python','多')
    li = coder('李四','php','不多不少')
    wang = coder('王五','c#','少')
    coders = [zhang,li,wang]
    return render(request,'templates.html',{'v_list':v_list,'v_dic':v_dic,'coders':coders})


def test_filter(request):
    vhair = "fewhair"
    return render(request,'test_filter.html',{'vhair':vhair})


def test_tag(request):
    return render(request,'test_tag.html')


def test_inclusion_tag(request):
    return render(request,'test_inclusion_tag.html')

def inhert(request):
    return render(request,'test_orm/base.html')