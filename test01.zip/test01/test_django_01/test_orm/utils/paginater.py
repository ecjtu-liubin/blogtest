class Paginater():
    def __init__(self,url_address,cur_page_num,total_rows,one_page_lines=10,page_maxtag=9):
        self.url_address = url_address
        self.page_maxtag = page_maxtag
        total_page,reminder = divmod(total_rows,one_page_lines)
        if reminder:
            total_page +=1
        self.total_page = total_page
        try:
            cur_page_num = int(cur_page_num)
            if cur_page_num >total_page:
                cur_page_num = total_page
            if cur_page_num == 0:
                cur_page_num = 1
        except Exception as e:
            cur_page_num = 1
        self.cur_page_num = cur_page_num
        self.rows_start = (cur_page_num - 1) * one_page_lines
        self.rows_end = cur_page_num * one_page_lines
        if total_page < page_maxtag:
            page_maxtag = total_page
        half_page_maxtag = page_maxtag // 2
        page_start = cur_page_num - half_page_maxtag
        page_end = cur_page_num + half_page_maxtag
        if page_start<=1:
            page_start = 1
            page_end = page_maxtag
        if page_end >=total_page:
            page_end = total_page
            page_start = total_page - page_maxtag +1
            if page_start <=1:
                page_start=1
        self.page_start = page_start
        self.page_end = page_end

    def html_page(self):
        html_page = []
        html_page.append('<li><a href="{}?page=1">首页</a></li>'.format(self.url_address))
        if self.cur_page_num <=1:
            html_page.append('<li class="disabled"><a href="#"><span aria-hidden="true">&laquo;</span></a></li>')
        else:
            html_page.append('<li><a href="{}?page={}"><span aria-hidden="true">&laquo;</span></a></li>'
                             .format(self.url_address,self.cur_page_num-1))
        for i in range(self.page_start,self.page_end+1):
            if i == self.cur_page_num:
                tmp = '<li class="active"><a href="{0}?page={1}">{1}</a></li>'.format(self.url_address,i)
            else:
                tmp = '<li><a href="{0}?page={1}">{1}</a></li>'.format(self.url_address,i)
            html_page.append(tmp)
        if self.cur_page_num >=self.total_page:
            html_page.append('<li class="disabled"><a href="#"><span aria-hidden="true">&raquo;</span></a></li>')
        else:
            html_page.append('<li><a href="{}?page={}"><span aria-hidden="true">&raquo;</span></a></li>'
                             .format(self.url_address,self.cur_page_num+1))
        html_page.append('<li><a href="{}?page={}">尾页</a></li>'.format(self.url_address,self.total_page))

        page_nav = "".join(html_page)
        return page_nav

    @property
    def data_start(self):
        return self.rows_start
    @property
    def data_end(self):
        return self.rows_end