from django import forms
from . import models
from django.core.exceptions import ValidationError
class reg_form(forms.Form):
    """定义了username字段类型为CharField，通过error_message设置对应出错类型的文字提示widget设置了字段在页面的表现形式，
    这里显示为inpu标签"""
    username=forms.CharField(
        max_length=20,
        label='账号',
        error_messages={
            "max_length":"登陆账号不能超过20位",
            "required":"登陆账号不能为空",
        },
        widget=forms.widgets.TextInput(
            attrs={"class":"form-control"}
        )
    )
    password = forms.CharField(
        min_length=6,
        label="密码",
        error_messages={
            'min_length':'密码最少6位',
            'required':'密码不能为空',
        },
        widget=forms.widgets.PasswordInput(
            attrs={'class':'form-control'},
            render_value=True,
        )
    )
    # 增加一个repassword字段，让用户在输入密码进行两次输入，保证注册密码正确
    repassword = forms.CharField(
        label='确认密码',
        min_length=6,
        error_messages={
            'min_length':'密码最少6位',
            'required':'密码不能为空',
        },
        widget=forms.widgets.PasswordInput(
            attrs={'class':'form-control'},
            render_value=True,
        )
    )
    nikename = forms.CharField(
        max_length=20,
        required=False,
        label='姓名',
        error_messages={
            'max_length':'姓名长度不能超过20位',
        },
        initial='无名氏',
        widget=forms.widgets.TextInput(
            attrs={'class':'form-control'}
        ),
    )
    email = forms.EmailField(
        label='邮箱',
        error_messages={
            'invalid':'邮箱格式错误',
            'required':'邮箱不能为空',
        },
        widget=forms.widgets.EmailInput(
            attrs={'class':'form-control'}
        )
    )
    telephone = forms.CharField(
        label='电话号码',
        required=False,
        max_length=11,
        error_messages={
            'max_length':'最大长度不超过11位',
        },
        widget=forms.widgets.TextInput(
            attrs={'class':'form-control'}
        )
    )
    head_img = forms.ImageField(
        label='头像',
        required=False,
        widget=forms.widgets.FileInput(
            attrs={'style': 'display:none'}
        )
    )
    # 定义一个校验字段的函数，校验字段函数命名是有规则的，形式：clean_字段名(),这个函数保证username值不重复
    def clean_username(self):
        uname = self.cleaned_data.get('username')
        vexist = models.loguser.objects.filter(username = uname)
        if vexist:
            self.add_error('username',ValidationError('登陆账号已存在！'))
        else :
            return uname
    def clean_password(self):
        passwd = self.cleaned_data.get('password')
        repasswd = self.cleaned_data.get('repassword')
        if repasswd and repasswd !=passwd:
            self.add_error('repassword',ValidationError('两次输入的密码不一致'))
        else:
            return repasswd