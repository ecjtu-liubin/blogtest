from django.db import models
from django.urls import reverse  # 对url进行解析
# 调用富文本编辑相关模块，从富文本编辑器ckeditor_uploader.field中导入RichTextUploadingField
from ckeditor_uploader.fields import RichTextUploadingField
# 导入strip_tags()函数，代码中用这个函数截取字段中的字符串
from django.utils.html import strip_tags
# Django用户认证系统提供了一个内置的User对象，我们通过扩展这个用户以增加新字段，扩展方式可以
# 通过继承AbstractUser的方式，所以要导入AbstractUser类
from django.contrib.auth.models import AbstractUser

# Create your models here.
class Category(models.Model):
    name = models.CharField(max_length=32,verbose_name='分类名')
    des = models.CharField(max_length=100,verbose_name='备注',null=True)
    def __str__(self):
        return self.name
    class Meta:
        verbose_name = '分类'
        verbose_name_plural = '分类'


class Tag(models.Model):
    name = models.CharField(max_length=32,verbose_name='标签名')
    des = models.CharField(max_length=100,verbose_name='备注')
    def __str__(self):
        return self.name
    class Meta:
        verbose_name = '标签'
        verbose_name_plural = '标签'


# 继承AbstractUser类就可以生成系统用户
class loguser(AbstractUser):
    nikename = models.CharField(max_length=32,verbose_name='昵称',blank=True)
    telephone = models.CharField(max_length=11,null=True,unique=True,verbose_name='电话',blank=True)
    head_img = models.ImageField(upload_to='headimage',blank=True,null=True,verbose_name='头像')
    def __str__(self):
        return self.username
    class Mate:
        verbose_name = '用户信息表'
        verbose_name_plural = verbose_name


class Blog(models.Model):
    title = models.CharField(max_length=70,verbose_name='文章标题')
    body = RichTextUploadingField(verbose_name='文本内容')
    created_time = models.DateTimeField(verbose_name='创建时间')
    modified_time = models.DateTimeField(verbose_name='修改时间')
    excerpt = models.CharField(max_length=200,blank=True,verbose_name='文章摘要')
    category = models.ForeignKey(to=Category,on_delete=models.CASCADE,verbose_name='分类')
    tags = models.ManyToManyField(to=Tag,blank=True,verbose_name='标签')
    author = models.ForeignKey(to=loguser,on_delete=models.CASCADE,verbose_name='作者')
    views = models.IntegerField(default=0,verbose_name='查看次数')
    def get_absolute_url(self):
        return reverse('blog:detail',kwargs={'pk':self.pk})
    def increase_views(self):
        self.views +=1
        self.save(update_fields=['views'])
    # save()函数是数据模型类的方法，重写这个方法是为了自动提取摘要内容
    def save(self,*args,**kwargs):
        if not self.excerpt:
            self.excerpt = strip_tags(self.body)[:118]
            super(Blog,self).save(*args,**kwargs)
        else:
            super(Blog,self).save(*args,**kwargs)
    def __str__(self):
        return self.title
    class Meta:
        ordering=['-created_time']
        verbose_name = '文档管理表'
        verbose_name_plural = '文档管理表'

