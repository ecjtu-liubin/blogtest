from django.db import models


# Create your models here.
class Comment(models.Model):
    name = models.CharField(max_length=32)
    email = models.EmailField(max_length=60)
    text = models.TextField()
    created_time = models.DateTimeField(auto_now_add=True)
    blog = models.ForeignKey(to='blog.Blog',on_delete=models.CASCADE,)
    def __str__(self):
        return self.text[:20]