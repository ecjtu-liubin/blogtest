from django.shortcuts import render,redirect,HttpResponse,get_object_or_404
from blog.models import Blog
from .forms import CommentForm
# Create your views here.
def blog_comment(request,blog_pk):
    blog = get_object_or_404(Blog,pk=blog_pk)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            # 生成Comment类的实例对象，但不立刻保存到数据库中
            comment = form.save(commit=False)
            comment.name = request.user.nikename
            comment.email = request.user.email
            # 通过外键关系将评论和被评论的文章联系起来
            comment.blog = blog
            comment.save()
            return redirect(blog)
        else:
            # 数据校验不通过需要重新渲染页面
            comment_list = blog.comment_set.all()
            context = {
                'blog':blog,'form':form,comment_list:comment_list
            }
            return render(request,'blog.detail.html',context=context)

    return redirect(blog)